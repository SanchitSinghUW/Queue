const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient();
require('./patch.js');

// exports.handler = async (event, context, callback) => {
//     //console.log('Received event:', JSON.stringify(event, null, 2));
//     // for (const record of event.Records) {
//     //     console.log(record.eventID);
//     //     console.log(record.eventName);
//     //     console.log('DynamoDB Record: %j', record.dynamodb);
//     // }
//     // return `Successfully processed ${event.Records.length} records.`;
//     let baseUrl = 'https://hlxwa7203m.execute-api.us-west-2.amazonaws.com/Test/@connections/'
//     let params = {
//         TableName: "users"
//     }
//     ddb.scan(params, function(err, data) {
//         if (err) {
//             console.log(err);
//         } else {
//             data.Items.forEach((user) => {
//                 let https = require("https");
//                 let payload = JSON.stringify(event.Records);
                
//                 let options = {
//                     hostname: "https://hlxwa7203m.execute-api.us-west-2.amazonaws.com/Test/@connections/",
//                     method: "POST",
//                     path: user.session_id
//                 }
                
//                 let request = https.request(options, (res) => res.on("data", () => callback(null, "OK")));
//                 request.write(payload);
//                 request.close();
//             })
//         }
//     });
    
//     //POST https://hlxwa7203m.execute-api.us-west-2.amazonaws.com/Test/@connections

// };
exports.handler = (event, context, callback) => {  
    //note, right now we are assuming that we only receive one record per 
    //trigger. this could be totally wrong. might have to loop over all records. 
    
    
    init(event);  
    let message = JSON.stringify(event.Records[0].dynamodb.NewImage)
    getConnections().then((data) => {        
        console.log(data.Items);        
        data.Items.forEach(function(connection) {         
            try{
                console.log("Connection " + connection.session_id);    
                // this line will error out if connection dne
                send(connection.session_id, message);
            } catch (e) {
            
            }
        });    
    });        
    return {
        statusCode: 200,
        body: JSON.stringify('Connected!'),
    }
    
    
};

let send = undefined;
function init(event) {  
    console.log(event)    
    const apigwManagementApi = new AWS.ApiGatewayManagementApi({    
        apiVersion: '2018-11-29',    
        endpoint: "https://hlxwa7203m.execute-api.us-west-2.amazonaws.com/Test" 
    });       
    
    
    send = async (connectionId, data) => {  
        try{
            await apigwManagementApi.postToConnection({ 
                ConnectionId: connectionId, Data: `${data}` }).promise(); 
        } catch (e) {
            let params = {
                TableName: "user",
                Key:{
                    "session_id": connectionId
                }
            }
            ddb.delete(params, function(err, data) {
            if (err) {
                console.error("Unable to delete item. Error JSON:", JSON.stringify(err, null, 2));
            } else {
                console.log("DeleteItem succeeded:", JSON.stringify(data, null, 2));
            }
        })
        }
    }

}
    
    
function getConnections(){
    return ddb.scan({        
            TableName: 'user',    
        }).promise();
}
