exports.handler = (event, context, callback) => {
    let result = "denied";
    if(event.code === "696969"){
        result = "passed"
    }
    
    callback(null, result);
    
    const response = {
        statusCode: 200,
        body: JSON.stringify("AWS"),
    };
    return response;
};
