const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB({region : 'us-west-2', apiVersion: '2012-08-10'});

exports.handler = (event, context, callback) => {
    //callback(null, event);
    let companyName = event.company;
    //get data from positions for company
    //for each field in the params, update the data from positions
    //put
    
    let params = {
        Key: {
            "company_name": {
                S: companyName
            }
        },
        TableName: "positions"
    };
        
    dynamodb.getItem(params, function(err, data){
        if (err) {
            console.log(err);
        }else{
            let returnParamItem = {
                company_name: {
                    S: companyName
                }
            };
            data = data.Item;
            Object.keys(data).forEach((key) => {
                if(key !== "company_name"){
                    let trueCount = parseInt(data[key].M.true.N);
                    let falseCount = parseInt(data[key].M.false.N);
                    let updateBoolean = event[key];
                    if(updateBoolean === "true"){
                        trueCount++;  
                    }else if(updateBoolean === "false"){
                        falseCount++;
                    }
                    let local = {
                        true: {
                            N: "" + trueCount
                        },
                        false: {
                            N: "" + falseCount
                        },
                    };
                    returnParamItem[key] = {M: local};
                }
            });
            
            
            let params = {
                    Item: returnParamItem,
                    TableName: "positions"
                }
            dynamodb.putItem(params, function(err, data){
                    if(err){
                        console.log(err);
                    }
                });
        }
    });
};
