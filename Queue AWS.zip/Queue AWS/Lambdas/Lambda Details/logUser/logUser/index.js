const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB({region : 'us-west-2', apiVersion: '2012-08-10'});

exports.handler = (event, context, callback) => {
    //remove JSON.parse for testing with Lambda
    let recieved = JSON.parse(event.body);
    let put = recieved.data.charAt(0) === '0' ? false : true;
    let company = recieved.data.substring(1, recieved.data.length);
    let currDate = new Date();
    
    //we are logging everything that a user does in order to produce dashboards later. 
    //comment if $$$$ or slow
    let logParams = {
        Item: {
                "time" : {
                    S: "" + currDate
                },
                "session_id": {
                    S: event.requestContext.connectionId
                },
                "company_name": {
                    S: company
                },
                "put": {
                    S: "" + put
                }
            },
            TableName: "logAllEvents"
    };
    dynamodb.putItem(logParams, function(err, data) {
                            if(err){
                                console.log(err);
                            }
    });
    
    let err = {};
    if (put) {
        let params = { 
            Item: {
                "session_id": {
                    S: event.requestContext.connectionId
                },
                "company_name": {
                    S: company
                },
                "start_time": {
                    S: "" + currDate
                }
            },
            TableName: "user"
        };
        
        dynamodb.putItem(params, function(err, data) {
            
            if (err) {
                console.log(err);
            } else {
                updateClient(true, company);
            }
            callback(null, {
              statusCode: err ? 500 : 200,
              body: err ? "Failed to connect: " + JSON.stringify(err) : "Connected"
            });
        })
    } else {
        let params = { 
            Key: {
                "session_id": {
                    S: event.requestContext.connectionId
                }
            },
            TableName: "user"
        };
    
        dynamodb.getItem(params, function(err, data) {
            if (err) {
                console.log(err);
            } else {
                let companyName = data.Item.company_name;
                let timeDiff = currDate - new Date(data.Item.start_time.S);
                timeDiff = Math.round(((timeDiff % 86400000) % 3600000) / 60000); // Time difference in minutes
                let totalDifference = data.Item.totalDifference === undefined ? 0 : parseInt(data.Item.totalDifference.N);

                params = { 
                    Item: {
                        "session_id": {
                            S: event.requestContext.connectionId
                        }
                    },
                    TableName: "user"
                };
                
                dynamodb.putItem(params, function(err, data) {
                    if (err) {
                        console.log(err, err.stack);
                    } else {
                        if (timeDiff >= totalDifference / 4) {
                            updateClient(false, company, timeDiff);
                        }
                        //updateClient(false, company, timeDiff);
                    }
                    callback(null, {
                      statusCode: err ? 500 : 200,
                      body: err ? "Failed to connect: " + JSON.stringify(err) : "Connected"
                    });
                })
            }

        })
    }
    
    //we are assuming an optimistic approach, that we will not have an exact
    //same concurrent access to the old counts. If we are seeing issues in the 
    //future with inaccuracy, we will have to perform a manual count from
    //our users table.
    let updateClient = (upOrDown, company, timeDiff) => {
        let count = 0;
        let params = {
            Key: {
                "company_name": {
                    S: company
                }
            },
            TableName: "company_info"
        }
        
        dynamodb.getItem(params, function(err, data) {
            if (err){
                console.log(err, err.stack); // an error occurred
            } else {
                count = parseInt(data.Item.line_size.N);
                //old description, otherwise overwritten
                let description = data.Item.description.S;
                //old positions, otherwise overwritten
                let positions = data.Item.positions;
                
                //if this is the first time someone is enqueueing, 
                //else, we preserve the old time. Same happens for countDequeued.
                let countDequeued;
                
                if(data.Item.countDequeued === undefined){
                    countDequeued = 0;
                }else{
                    countDequeued = parseInt(data.Item.countDequeued.N);
                }
                
                //if people exist and we are dequeueing, then decrease dequeued
                if(count !== 0 && !put){
                    countDequeued = parseInt(data.Item.countDequeued.N) + 1;
                }
                
                let totalDifference = data.Item.totalDifference === undefined ? 0 : parseInt(data.Item.totalDifference.N);
                
                if(upOrDown){
                    count++;
                }else{
                    count--;
                    //we are also adding the cumulitive time sum when someone dequeues
                    totalDifference += timeDiff;
                }
                
                if (count < 0) {
                    console.log("DATA: \n");
                    console.log(data);
                }
        
        
                let oldItem = data.Item;
                oldItem["company_name"] = {
                            S: company
                        };
                oldItem["line_size"] = {
                            N: "" + count
                        };
                oldItem["description"] = {
                           S: "" + description
                        };
                oldItem["positions"] = positions;
                oldItem["countDequeued"] = {
                            N: "" + countDequeued
                        };
                oldItem["totalDifference"] = {
                            N: "" + totalDifference
                        };
                        
                let newParams = {
                    Item: oldItem,
                    TableName: "company_info"
                }
                
                dynamodb.putItem(newParams, function(err, data){
                    if(err){
                        console.log(err);
                    }
                });
            }
        });
    }
    
    return {
            statusCode: 200,
            body: JSON.stringify('Connected!'),
    }
    
};