const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB({region : 'us-west-2', apiVersion: '2012-08-10'});

exports.handler = (event, context, callback) => {
    console.log("LOGGING: \n")
    console.log(event);
    console.log(event.Records[0].dynamodb);
    let data = (event.Records[0].dynamodb.NewImage);
    //read the company name of the trigger
    let companyName = data.company_name.S;
    
    let params = { 
            Key: {
                "company_name": {
                    S: companyName
                }
            },
            TableName: "company_info"
        };
    
    //read the corresponding row of the companyInfo table
    dynamodb.getItem(params, function(err, tableData) {
            if (err) {
                console.log(err);
            } else {
                //calculate the current ratios for ALL and update the companyInfo table
                //if true/(true + false) > 90, result is true
                //if false/(true + false) > 90, result is false
                //else NA
                let count = tableData.Item.line_size === undefined ? 0 : parseInt(tableData.Item.line_size.N);
                let description = tableData.Item.description.S;
                let positions = tableData.Item.positions;
                let totalDifference = tableData.Item.totalDifference === undefined ? 0 : parseInt(tableData.Item.totalDifference.N);
                let countDequeued = tableData.Item.countDequeued === undefined ? 0 : parseInt(tableData.Item.countDequeued.N);
                //initialize the resultParamItem
                let resultParamItem = {
                        "company_name": {
                            S: companyName
                        },
                        "line_size" : {
                            N: "" + count
                        },
                        "description" : {
                            S: "" + description
                        },
                        "positions" : positions,
                        "countDequeued" : {
                            N: "" + countDequeued
                        },
                        "totalDifference" : {
                            N: "" + totalDifference
                        }
                };
                
                let updateCompanyInfo = false;
                //for each field other than company name
                Object.keys(data).forEach((key) => {
                    if(key !== "company_name"){
                        //read current ratios
                        
                        let trueCount = parseInt(data[key].M.true.N);
                        let falseCount = parseInt(data[key].M.false.N);
                        
                        //use those rations to calculate T or F or NA
                        let totalCount = trueCount + falseCount;
                        let flag = "NA";
                        if(trueCount/totalCount >= 0.75 && trueCount >= 5){
                            flag = "T";
                        }else if(falseCount/totalCount >= 0.75 && falseCount >= 5){
                            flag = "F";
                        }
                        
                        //compare to existing column
                        let currentFlag = tableData.Item[key];
                        
                        //builds the resultParamItem from above with the new or old values
                        if(flag !== currentFlag){
                            resultParamItem[key] = {S: "" + flag};
                            updateCompanyInfo = true;
                        }else{
                            resultParamItem[key] = {S: "" + currentFlag};
                        }
                    }
                });
                
                let newParams = {
                    Item: resultParamItem,
                    TableName: "company_info"
                }
                
                //only update the table if something changed
                if(updateCompanyInfo){
                    dynamodb.putItem(newParams, function(err, data){
                        if(err){
                            console.log(err);
                        }
                    });
                }
            }
        }    
    );
    
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
