const AWS = require('aws-sdk');
const dynamodb = new AWS.DynamoDB({region : 'us-west-2', apiVersion: '2012-08-10'});

exports.handler = (event, context, callback) => {
    let params = {
      TableName: "company_info"
    };
    
    dynamodb.scan(params, function(err, data) {
       if (err) {
           console.log(err, err.stack); // an error occurred
       } else {
           callback(null, parser(data));
       }
    });
};

const parser = (data) => {
    let items = data.Items;
    let result = {};
    
    items.forEach((value) => {
        let companyName = value.company_name.S;
        let positions = [];
        let dataPos = value.positions.L;
        dataPos.forEach((pos) => {
            positions.push(pos.S);
        });
        let description = value.description.S;
        let line_size = value.line_size.N;
        let startTime = value.startTime === undefined ? new Date().toString() : value.startTime.S;
        let countDequeued = value.countDequeued === undefined ? 1 : value.countDequeued.N;
        let totalDifference = value.totalDifference === undefined ? 0 : parseInt(value.totalDifference.N);
        let internship = value.Internship.S;
        let fulltime = value["Full-Time"].S;
        let parttime = value["Part-Time"].S;
        let sponsorship = value.Sponsorship.S;
        let resume = value.Resume.S;
        let onsiteInterview = value["Onsite Interview"].S;
        result[companyName] = {
            positions: positions,
            description: description,
            line_size: line_size,
            countDequeued: countDequeued,
            totalDifference: totalDifference,
            Internship: internship,
            "Full-Time": fulltime,
            "Part-Time": parttime,
            Sponsorship: sponsorship,
            Resume: resume,
            "Onsite Interview": onsiteInterview
        };
    });    
    return result;
}
