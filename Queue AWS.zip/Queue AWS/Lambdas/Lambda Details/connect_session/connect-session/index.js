const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient();

exports.handler = function(event, context, callback) {
  var putParams = {
    TableName: 'user',
    Item: {
      session_id: event.requestContext.connectionId
    }
  };

  ddb.put(putParams, function(err, data) {
    callback(null, {
      statusCode: err ? 500 : 200,
      body: err ? "Failed to connect: " + JSON.stringify(err) : "Connected"
    });
  });
  
};
