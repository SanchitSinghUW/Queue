This is the backend of Queue hosted on AWS using the SAM (server-less application management) framework. The code was developed entirely on the AWS console, what you see here is just some code and screenshots of how the console was setup.

Learing Sources:
1 - AWS - SAMhttps://www.udemy.com/course/aws-serverless-a-complete-introduction/
2 - AWS - Websocket https://docs.aws.amazon.com/apigateway/latest/developerguide/apigateway-websocket-api.html
3 - Learn React Native (you don't really need to learn React beforehand)

How it all interacts:

- The frontend will make API requests to AWS API Gateway
- Based on the URL of the API request, an appropriate API Gateway will be called
- As you can see the screenshots, each API Gateway is connected to a Lambda Function
- The Lambda function will may interact with the database (DynamoDB) to put/get data. The lambda will then return the necessary data
- API Gateway will respond with the data (or anything you specify) to the frontend
- The frontend will parse the JSON data and move on with life

Note, the application also runs in real time. As in, if someone signs into a line, all the connected session apps are notified in real time (not using a timely request, actual Real Time). You may change this design to use timely API requests to get the queue length, but we're ballers and we wanted real time so here we are. It's called WebSockets if you want to learn how that works. 

It's okay to code on the console, but at Amazon (internship), I rarely touched the console. Instead, I used what's called an SDK, which formalizes coding on AWS. I recommend you do that.

Anyway, contact me at sanchit.singh@live.co.uk or 408 621 8843 for questions.
Sanchit, Albert, June